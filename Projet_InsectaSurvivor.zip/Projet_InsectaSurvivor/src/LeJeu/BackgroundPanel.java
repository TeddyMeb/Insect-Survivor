/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LeJeu;
import javax.swing.*;
import java.awt.*;
/**
 *
 * @author nsebasti
 */
public class BackgroundPanel extends JPanel { 
    private Image img;

    public BackgroundPanel() {
        img = new ImageIcon(getClass().getResource("/pokemon/folder/im.png")).getImage();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(img, 0, 0, getWidth(), getHeight(), this);
    }

}
