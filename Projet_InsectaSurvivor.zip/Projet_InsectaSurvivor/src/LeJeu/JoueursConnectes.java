/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LeJeu;

import java.util.ArrayList;
/**
 *
 * @author nsebasti
 */
public class JoueursConnectes {
    public static ArrayList<String> liste = new ArrayList<>();
}
