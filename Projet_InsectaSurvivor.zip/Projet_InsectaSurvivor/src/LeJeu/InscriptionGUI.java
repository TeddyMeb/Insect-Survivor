/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LeJeu;
import jdbc.TestInsert;
import javax.swing.WindowConstants;
import jdbc.TestInsert;
import javax.swing.*;
/**
 *
 * @author nsebasti
 */

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author nsebasti
 */
public class InscriptionGUI extends JFrame {
    private JTextField jTextFieldPseudo;
    private JPasswordField jPasswordFieldMdp;
    private JButton jButtonValider;


    public InscriptionGUI() {

        setTitle("Inscription");
        setSize(300, 200);
        setLayout(null);

        // pseudo
        JLabel labelPseudo = new JLabel("Pseudo :");
        labelPseudo.setBounds(50, 20, 200, 20);
        add(labelPseudo);

        jTextFieldPseudo = new JTextField();
        jTextFieldPseudo.setBounds(50, 40, 200, 30);
        add(jTextFieldPseudo);

        // mot de passe
        JLabel labelMdp = new JLabel("Mot de passe :");
        labelMdp.setBounds(50, 70, 200, 20);
        add(labelMdp);

        jPasswordFieldMdp = new JPasswordField();
        jPasswordFieldMdp.setBounds(50, 90, 200, 30);
        add(jPasswordFieldMdp);

        // bouton
        jButtonValider = new JButton("Créer");
        jButtonValider.setBounds(80, 130, 120, 30);
        add(jButtonValider);

        // action bouton (UNE SEULE FOIS ICI)
        jButtonValider.addActionListener(e -> creerCompte());

        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void creerCompte() {

        String pseudo = jTextFieldPseudo.getText().trim();
        String motdepasse = new String(jPasswordFieldMdp.getPassword()).trim();

        if (pseudo.isEmpty() || motdepasse.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Champs vides !");
            return;
        }

        try {
            TestInsert.insererJoueur(pseudo, motdepasse);

            JOptionPane.showMessageDialog(this, "Compte créé !");
            this.dispose();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Erreur BDD !");
            e.printStackTrace();
        }
    }

}

