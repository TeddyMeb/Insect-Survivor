/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LeJeu;

import java.sql.Connection;
import java.sql.PreparedStatement;

/**
 *
 * @author nsebasti
 */
public class Joueur {
    private String pseudo;
    private String motdepasse;

    public Joueur(String pseudo, String motdepasse) {
        this.pseudo = pseudo;
        this.motdepasse = motdepasse;
    }

    public String getPseudo() {
        return pseudo;
    }

    public String getMotdepasse() {
        return motdepasse;
    }
}