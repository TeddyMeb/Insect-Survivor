/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jdbc;

import outils.OutilsJDBC;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;   // 🔥 celui-là est souvent oublié
import java.sql.SQLException;

/**
 *
 * @author guillaume.laurent
 */
public class TestInsert {
    

    public static void insererJoueur(String pseudo, String motdepasse) {

        try {
            Connection connexion = DriverManager.getConnection(
                "jdbc:mariadb://nemrod.ens2m.fr:3306/2025-2026_s2_vs2_tp1_InsectSurvivor",
                "etudiant",
                "YTDTvj9TR3CDYCmP"
            );

            String sql = "INSERT INTO joueurs (pseudo, motdepasse, x, y, score, last_update, classe) VALUES (?, ?, 0, 0, 0, NOW(), NULL)";
            PreparedStatement stmt = connexion.prepareStatement(sql);

            stmt.setString(1, pseudo);
            stmt.setString(2, motdepasse);

            stmt.executeUpdate();

            stmt.close();
            connexion.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
   