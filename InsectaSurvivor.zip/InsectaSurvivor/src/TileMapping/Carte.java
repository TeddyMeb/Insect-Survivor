/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TileMapping;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import java.io.*;
import java.util.*;

/**
 * Exemple de classe carte
 *
 * @author guillaume.laurent
 */
public class Carte {

    private int largeur = 52;
    private int hauteur = 29;
    private int tailleTuile = 32;
    int[][] decor = new int[hauteur][largeur];
    
    
    private BufferedImage uneTuile;
    
    private BufferedImage[] tuiles;
   
//    private int[][] decor = {
//        { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
//        { 0, 0, 26, 26, 26, 0, 0, 0, 0, 0, 0, 0},
//        { 0, 0, 26, 20, 26, 0, 0, 0, 0, 0, 0, 0},
//        { 0, 0, 26, 20, 26, 0, 0, 0, 0, 0, 57, 2},
//        { 0, 0, 0, 20, 0, 0, 0, 0, 0, 1, 2, 3},
//        { 2, 2, 0, 20, 0, 0, 57, 0, 18, 18, 1, 1},
//        { 3, 3, 2, 2, 2, 2, 2, 2, 1, 1, 1, 1},
//        { 3, 3, 3, 3, 3, 3, 3, 3, 1, 1, 1, 1},
//        { 1, 1, 3, 3, 3, 3, 3, 1, 1, 16, 1, 105}
//    };
    


    public Carte() {
    try {
        BufferedImage tileset = ImageIO.read(getClass().getResource("images/foret2.png"));  ///tileSetMinecraft32x32.png Niveau1.txt    pokemon32x32.png  123.txt

        tuiles = new BufferedImage[1508];
        for (int i = 0; i < tuiles.length; i++) {
            int x = (i % 52) * tailleTuile;
            int y = (i / 52) * tailleTuile;
            tuiles[i] = tileset.getSubimage(x, y, tailleTuile, tailleTuile);
            }
            try (BufferedReader fichier = new BufferedReader(new FileReader("Z:\\Documents\\Mon Projet Info\\TP_GUI\\Tuto_GUI\\src\\TileMapping\\foret2.1.txt"))) {
                    String ligne;
                    while ((ligne = fichier.readLine()) != null) {

                    System.out.println(ligne);
            }
                    } catch (IOException e) {
                       e.printStackTrace();
                    }

      
        

    } catch (IOException ex) {
        ex.printStackTrace();
    }

    

       

        try {
            BufferedReader reader = new BufferedReader(new FileReader("Z:\\Documents\\Mon Projet Info\\TP_GUI\\Tuto_GUI\\src\\TileMapping\\foret2.1.txt"));
            String ligne;
            int numeroLigne = 0;

            while ((ligne = reader.readLine()) != null) {
        numeroLigne++;
        if (numeroLigne < 4) continue; // ignorer les trois premières lignes

        if (numeroLigne - 4 >= hauteur) break; // sécurité si trop de lignes

        String[] parties = ligne.trim().split("\\s+"); // découpe sur un ou plusieurs espaces

        for (int col = 0; col < Math.min(parties.length, largeur); col++) {
            decor[numeroLigne - 4][col] = Integer.parseInt(parties[col]);
        }
    }
} catch (IOException e) {
    e.printStackTrace();
}

for (int i = 0; i < hauteur; i++) {
    System.out.println(Arrays.toString(decor[i]));
}


}
    
    public void rendu(Graphics2D contexte) {
        
        
        for (int i = 0; i<hauteur; i++){
            for (int j=0; j<largeur ; j++){
                
                int numeroTuile = decor[i][j];
                
                int y = i*tailleTuile;
                int x = j*tailleTuile;
                
                contexte.drawImage(tuiles[numeroTuile], x, y, null);
            }
            
        }
    }    
    
 

    public void miseAJour() {

    }
}










//private void chargerCarteDepuisFichier(String chemin) {
//    List<Integer> toutesValeurs = new ArrayList<>();
//    try (BufferedReader fichier = new BufferedReader(new FileReader("Z:\\Documents\\info vert info\\tp_mapping\\TP_TileMapping\\build\\classes\\FruitEditor\\JSP.txt"))) {
//
//        java.util.List<String> lignes = new java.util.ArrayList<>();
//        String ligne;
//
//        while ((ligne = fichier.readLine()) != null) {
//            lignes.add(ligne);
//        }
//
//        hauteur = lignes.size();
//        largeur = lignes.get(0).split(" ").length;
//
//        decor = new int[hauteur][largeur];
//
//        for (int i = 0; i < hauteur; i++) {
//            String[] valeurs = lignes.get(i).split(" ");
//            for (int j = 0; j < largeur; j++) {
//                decor[i][j] = Integer.parseInt(valeurs[j]);
//            }
//        }