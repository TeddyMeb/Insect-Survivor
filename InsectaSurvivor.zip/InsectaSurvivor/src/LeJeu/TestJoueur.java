/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package LeJeu;
import java.util.List;
/**
 *
 * @author nsebasti
 */
public class TestJoueur {
    public static void main(String[] args) {



        JoueurDAO dao = new JoueurDAO();

        List<Joueur> joueurs = dao.getAllJoueurs();

        for (Joueur j : joueurs) {
            System.out.println(j.getPseudo() + " - " + j.getMotDePasse());
        }
    }
    
}
