/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LeJeu;
import java.util.ArrayList;
import java.util.List;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
/**
 *
 * @author nsebasti
 */

public class JoueurDAO {
    
    public void ajouter(Joueur j) {
    try {
        Connection conn = outils.SingletonJDBC.getInstance().getConnection();

        String sql = "INSERT INTO dresseurs (pseudo, motDePasse) VALUES (?, ?)";
        PreparedStatement stmt = conn.prepareStatement(sql);

        stmt.setString(1, j.getPseudo());
        stmt.setString(2, j.getMotDePasse()); // ou md5 si tu veux

        stmt.executeUpdate();

        System.out.println("Joueur ajouté : " + j.getPseudo());

    } catch (Exception e) {
        e.printStackTrace();
    }
}
    
    public boolean verifierLogin(String pseudo, String mdp) {
        // SELECT FROM BDD
        return false;
    }
    public void testAjout() {

    Joueur j1 = new Joueur("Red", "123");
    Joueur j2 = new Joueur("Blue", "456");

    ajouter(j1);
    ajouter(j2);
}
    public List<Joueur> getAllJoueurs() {

    List<Joueur> liste = new ArrayList<>();

    try {
        Connection conn = outils.SingletonJDBC.getInstance().getConnection();

        String sql = "SELECT * FROM dresseurs";
        PreparedStatement stmt = conn.prepareStatement(sql);

        ResultSet rs = stmt.executeQuery();

        while (rs.next()) {
            String pseudo = rs.getString("pseudo");
            String mdp = rs.getString("motDePasse");

            Joueur j = new Joueur(pseudo, mdp);
            liste.add(j);
        }

    } catch (Exception e) {
        e.printStackTrace();
    }
System.out.println("TEST MAIN");
    return liste;
}
 public static void main(String[] args) {

        JoueurDAO dao = new JoueurDAO();

        dao.testAjout(); // 🔥 ça va ajouter Red et Blue

    }  
 public boolean existe(String pseudo) {
    try {
        Connection conn = outils.SingletonJDBC.getInstance().getConnection();

        String sql = "SELECT * FROM dresseurs WHERE pseudo=?";
        PreparedStatement stmt = conn.prepareStatement(sql);

        stmt.setString(1, pseudo);

        ResultSet rs = stmt.executeQuery();

        return rs.next();

    } catch (Exception e) {
        e.printStackTrace();
        return false;
    }
}
}
