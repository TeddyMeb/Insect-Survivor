/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LeJeu;
import javax.swing.*;
import java.sql.*;
import java.awt.*;
import LeJeu.FenetreDeJeu;

/**
 *
 * @author nsebasti
 */
public class SalleAttenteGUI extends JFrame {
    private DefaultListModel<String> model;
    private JList<String> list;
    private String pseudo;
    private boolean jeuLance = false;
    JPanel panelClasses = new JPanel();


    private JButton boutonOK;
    
    public SalleAttenteGUI(String pseudo) {
        
        this.pseudo = pseudo;
        new Timer(2000, e -> verifierLancement()).start();

        setTitle("Salle d'attente - Lobby 4 joueurs");
        setSize(400, 500);
        setLayout(new BorderLayout());

        // 🎮 Titre
        JLabel titre = new JLabel("Salle d'attente (4 joueurs)", SwingConstants.CENTER);
        titre.setFont(new Font("Arial", Font.BOLD, 20));
        add(titre, BorderLayout.NORTH);

        // 🎮 Liste joueurs
        model = new DefaultListModel<>();
        list = new JList<>(model);

        list.setFont(new Font("Arial", Font.PLAIN, 18));

        JScrollPane scroll = new JScrollPane(list);
        add(scroll, BorderLayout.CENTER);
        // 🎮 PANEL CLASSES
JPanel panelClasses = new JPanel();
panelClasses.setLayout(new GridLayout(3, 2));

JButton btnFourmi = new JButton("Fourmi");
JButton btnMante = new JButton("Mante religieuse");
JButton btnGuepe = new JButton("Guêpe");
JButton btnScarabee = new JButton("Scarabée");
JButton btnResetClasse = new JButton("Reset classe");


panelClasses.add(btnFourmi);
panelClasses.add(btnMante);
panelClasses.add(btnGuepe);
panelClasses.add(btnScarabee);
panelClasses.add(btnResetClasse);
// à droite
add(panelClasses, BorderLayout.EAST);
btnFourmi.addActionListener(e -> choisirClasse("fourmi"));
    btnMante.addActionListener(e -> choisirClasse("mante_religieuse"));
    btnGuepe.addActionListener(e -> choisirClasse("guepe"));
    btnScarabee.addActionListener(e -> choisirClasse("scarabee"));
    btnResetClasse.addActionListener(e -> resetClasse());

        // 🎮 Bouton OK
        boutonOK = new JButton("OK - Prêt");
        boutonOK.setFont(new Font("Arial", Font.BOLD, 18));
        boutonOK.setBackground(Color.GREEN);

        add(boutonOK, BorderLayout.SOUTH);

        boutonOK.addActionListener(e -> ouvrirJeu());

        // 🔄 refresh automatique
        chargerJoueurs();
        new Timer(2000, e -> {
    chargerJoueurs();

    int nb = getNbJoueurs();

    // activation bouton seulement si 4 joueurs
    boutonOK.setEnabled(nb >= 4);

    // lancement auto
    if (nb >= 4 && !jeuLance) {
        jeuLance = true;
        lancerJeu();
    }
}).start();

        setLocationRelativeTo(null);
        setVisible(true);
    }
    private void resetClasse() {
    try {
        Connection conn = outils.SingletonJDBC.getInstance().getConnection();

        String sql = "UPDATE joueurs SET classe=NULL WHERE pseudo=?";
        PreparedStatement stmt = conn.prepareStatement(sql);

        stmt.setString(1, pseudo);
        stmt.executeUpdate();

        stmt.close();

        JOptionPane.showMessageDialog(this, "Classe réinitialisée !");

        chargerJoueurs();

    } catch (Exception e) {
        e.printStackTrace();
    }
}
   private void choisirClasse(String classeChoisie) {

    try {
        Connection conn = outils.SingletonJDBC.getInstance().getConnection();

        // 🔒 vérifier si déjà prise
        String check = "SELECT COUNT(*) AS nb FROM joueurs WHERE classe=?";
        PreparedStatement stmtCheck = conn.prepareStatement(check);
        stmtCheck.setString(1, classeChoisie);

        ResultSet rs = stmtCheck.executeQuery();

        if (rs.next() && rs.getInt("nb") > 0) {
            JOptionPane.showMessageDialog(this,
                "Classe déjà prise !");
            return;
        }

        rs.close();
        stmtCheck.close();

        // 🔒 vérifier si toi t'as déjà une classe
        String checkSelf = "SELECT classe FROM joueurs WHERE pseudo=?";
        PreparedStatement stmtSelf = conn.prepareStatement(checkSelf);
        stmtSelf.setString(1, pseudo);

        ResultSet rsSelf = stmtSelf.executeQuery();

        if (rsSelf.next() && rsSelf.getString("classe") != null) {
            JOptionPane.showMessageDialog(this,
                "Tu as déjà choisi une classe !");
            return;
        }

        rsSelf.close();
        stmtSelf.close();

        // ✅ update en BDD
        String sql = "UPDATE joueurs SET classe=? WHERE pseudo=?";
        PreparedStatement stmt = conn.prepareStatement(sql);

        stmt.setString(1, classeChoisie);
        stmt.setString(2, pseudo);

        stmt.executeUpdate();
        stmt.close();

        JOptionPane.showMessageDialog(this,
            "Classe choisie : " + classeChoisie);

        chargerJoueurs();

    } catch (Exception e) {
        e.printStackTrace();
    }
}
    private int getNbJoueurs() {
    int nb = 0;

    try {
        Connection conn = outils.SingletonJDBC.getInstance().getConnection();

        String sql = "SELECT COUNT(*) AS nb FROM joueurs WHERE connecte=1";
        PreparedStatement stmt = conn.prepareStatement(sql);

        ResultSet rs = stmt.executeQuery();

        if (rs.next()) {
            nb = rs.getInt("nb");
        }

        rs.close();
        stmt.close();

    } catch (Exception e) {
        e.printStackTrace();
    }

    return nb;
}
    private void lancerJeu() {
    JOptionPane.showMessageDialog(this, "4 joueurs connectés ! Lancement du jeu");

    new LeJeu.FenetreDeJeu().setVisible(true);
    this.dispose();
}
private void verifierLancement() {
    try {
        Connection conn = outils.SingletonJDBC.getInstance().getConnection();

        String sql = "SELECT COUNT(*) AS nb FROM joueurs WHERE connecte=1";
        PreparedStatement stmt = conn.prepareStatement(sql);

        ResultSet rs = stmt.executeQuery();

        if (rs.next()) {
            int nb = rs.getInt("nb");

            // 🔥 ICI
            if (nb >= 4 && !jeuLance) {
                jeuLance = true;
                lancerJeu();
            }
        }

        rs.close();
        stmt.close();

    } catch (Exception e) {
        e.printStackTrace();
    }
}
    // 🎮 OUVERTURE FENÊTRE JEU
    private void ouvrirJeu() {

    int nb = getNbJoueurs();

    if (nb < 4) {
        JOptionPane.showMessageDialog(this,
            "Il faut 4 joueurs pour lancer la partie !");
        return;
    }

    lancerJeu();
}
    // 🔴 déconnexion
    private void deconnecter() {
    try {
        Connection conn = outils.SingletonJDBC.getInstance().getConnection();

        String sql = "UPDATE joueurs SET connecte=0, classe=NULL WHERE pseudo=?";
        PreparedStatement stmt = conn.prepareStatement(sql);

        stmt.setString(1, pseudo);
        stmt.executeUpdate();

        stmt.close();

        System.out.println("Déconnexion + reset classe OK");

    } catch (Exception e) {
        e.printStackTrace();
    }
}

    // 👀 joueurs connectés
    private void chargerJoueurs() {
        try {
            Connection conn = outils.SingletonJDBC.getInstance().getConnection();

            String sql = "SELECT pseudo, classe FROM joueurs WHERE connecte=1 LIMIT 4";
            PreparedStatement stmt = conn.prepareStatement(sql);

            ResultSet rs = stmt.executeQuery();

            model.clear();

            while (rs.next()) {
                String pseudo = rs.getString("pseudo");
String classe = rs.getString("classe");

model.addElement(pseudo + " - " + (classe != null ? classe : "Pas choisi"));
            }

            rs.close();
            stmt.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
         setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);

    addWindowListener(new java.awt.event.WindowAdapter() {
        @Override
        public void windowClosing(java.awt.event.WindowEvent e) {
            deconnecter();
            dispose();
        }
    });

    setLocationRelativeTo(null);
    setVisible(true);
    }

}

